# Getting Started

TODO: A quick guide to writing your first unit test.  This should not get into all the options available instead it should link to that documentation where it is appropriate.    This really should be a high level look at the product.   It should take the point of view of someone who has never written a unit test in any language.
 

