#How to upgrade from prior versions

TODO: Finish this documentation.