
### Version 3 Major Contributors 
Listed Alphabetically 

| Name          | GitHub account  
| ------------  | --------------
| David Pyke    | [Shoelace](https://github.com/Shoelace)
| Jacek Gebal   | [jgebal](https://github.com/jgebal)
| Pavel  Kaplya | [Pazus](https://github.com/Pazus)
| Robert Love   | [rlove](https://github.com/rlove)

### Special thanks to prior major contributors.

- Steven Feuerstein - Original Author
- Chris Rimmer
- Patrick Barel
- Paul Walker
