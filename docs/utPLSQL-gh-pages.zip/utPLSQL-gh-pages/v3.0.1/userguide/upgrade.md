# How to upgrade from prior versions

utPLSQL v3 is a total rewrite of the previous version. There is no automated way to migrate tests from version 2.x to version 3.
There are plans to build a mapping/bridging solution that would allow running v2 tests using v3 framework.

