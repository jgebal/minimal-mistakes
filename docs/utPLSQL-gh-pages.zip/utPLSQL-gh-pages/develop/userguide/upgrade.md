# Upgrading from version 2

utPLSQL v3 is a total rewrite of the framework.
To make utPLSQL v2 packages run on v3 framework you need to install and execute migration utility.
See the [utPLSQL-v2-v3-migration](https://github.com/utPLSQL/utPLSQL-v2-v3-migration) project for details on how to install and execute the migration.


