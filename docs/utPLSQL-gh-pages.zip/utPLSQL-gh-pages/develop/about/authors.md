
### utPLSQL v3 Major Contributors 

**Listed Alphabetically** 

| Name             | GitHub account  
| ---------------- | --------------
| David Pyke       | [Shoelace](https://github.com/Shoelace)
| Jacek Gebal      | [jgebal](https://github.com/jgebal)
| Pavel  Kaplya    | [Pazus](https://github.com/Pazus)
| Robert Love      | [rlove](https://github.com/rlove)
| Vinicius Avellar | [viniciusam](https://github.com/viniciusam/)
| Samuel Nitsche   | [pesse](https://github.com/pesse/)
| Lukasz Wasylow   | [lwasylow](https://github.com/lwasylow/)



Many thanks to all the [contributors](https://github.com/utPLSQL/utPLSQL/graphs/contributors)

### Special thanks to prior major contributors

- Steven Feuerstein - Original Author
- Chris Rimmer
- Patrick Barel
- Paul Walker
