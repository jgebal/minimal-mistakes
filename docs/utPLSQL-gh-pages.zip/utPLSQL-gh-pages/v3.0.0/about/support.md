# How to get support

- Feel free post questions, bugs or issues in the [issues area of GitHub](https://github.com/utPLSQL/utPLSQL/issues).
- Join developers the [utPLSQL team](http://utplsql-slack-invite.herokuapp.com) on [Slack](https://slack.com/)
